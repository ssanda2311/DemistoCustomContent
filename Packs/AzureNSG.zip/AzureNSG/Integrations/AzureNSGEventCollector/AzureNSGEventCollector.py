# -*- coding: utf-8 -*-
"""
Azure NSG Flow Logs -> Cortex XSIAM Event Collector (Updated)
-------------------------------------------------------------
- fetch-events: reads NSG JSON blobs from Azure Storage and sends transformed events to XSIAM.
- test-module: connectivity test to storage account/container.
Key updates:
* Azure download tuning (max_single_get_size, max_chunk_get_size, max_concurrency) for faster, more reliable downloads.
* Chunked/batched sends to XSIAM via send_events_to_xsiam().
* Clean returns to avoid decoder (2605) errors; no raw prints.
* Per-blob indexing to avoid duplicate event ingestion.
"""
import demistomock as demisto
import re
import json
import time
import traceback
import threading
import os
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Iterable, List, Tuple
       # send_events_to_xsiam
# Azure Blob SDK
from azure.core.exceptions import AzureError
from azure.storage.blob import (
    BlobServiceClient,
    BlobClient,
    BlobPrefix,
    BlobProperties
)
# Concurrency
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed

# ----------------------
# Helpers & Constants
# ----------------------
DEFAULT_MAX_WORKERS = 10           # Upper bound for blob-parallelism
DEFAULT_DOWNLOAD_TIMEOUT = 120     # Seconds for Azure blob client download call
DEFAULT_RETRY_DELAY_BASE = 2       # Backoff base (seconds)
DEFAULT_RETRY_ATTEMPTS = 3         # Retries for blob download/parsing
DEFAULT_BATCH_SIZE = 100000         # Events per send_events_to_xsiam() call
DEFAULT_MAX_SINGLE_GET_SIZE_MB = 64   # Single-call GET threshold (MiB)
DEFAULT_MAX_CHUNK_GET_SIZE_MB = 8     # Chunk size for parallel GETs (MiB)
DEFAULT_MAX_CONCURRENCY = 2           # Per-blob parallel range requests
def chunked(seq: List[Dict[str, Any]], size: int) -> Iterable[List[Dict[str, Any]]]:
    """Yield lists of length 'size' from seq."""
    for i in range(0, len(seq), size):
        yield seq[i:i + size]

# ----------------------
# Connectivity Test
# ----------------------
def test_module():
    """Simple connectivity test to Azure Blob container."""
    params = demisto.params()
    try:
        conn_str = params.get("connection_string")
        container_name = params.get("container_name")
        # Download tuning (optional)
        max_single_get_size = int(params.get("max_single_get_size_mb", DEFAULT_MAX_SINGLE_GET_SIZE_MB)) * 1024 * 1024
        max_chunk_get_size = int(params.get("max_chunk_get_size_mb", DEFAULT_MAX_CHUNK_GET_SIZE_MB)) * 1024 * 1024
        blob_service_client = BlobServiceClient.from_connection_string(
            conn_str=conn_str,
            max_single_get_size=max_single_get_size,
            max_chunk_get_size=max_chunk_get_size
        )
        container_client = blob_service_client.get_container_client(container_name)
        container_client.get_container_properties()
        return_results("ok")
    except Exception as e:
        return_error(f"Test failed: {str(e)}")

# ----------------------
# Parser for Azure NSG
# ----------------------
class NSGFlowLogParser:
    """
    Discover and read Azure NSG Flow Logs blobs under prefixes like:
    <resource_id>/y=YYYY/m=MM/d=DD/h=HH/...
    JSON layout expected:
      {
        "records": [
          {
            "time": "...",
            "macAddress": "...",
            "resourceId": "...",
            "operationName": "...",
            "version": "...",
            "properties": {
              "flows": [
                { "rule": "...", "flows": [ { "flowTuples": ["..."] } ] }
              ]
            }
          }
        ]
      }
    """
    def __init__(self, blob_service_client: BlobServiceClient, container_name: str):
        self.client = blob_service_client.get_container_client(container_name)
        # Matches folder ending "y=YYYY/" and captures the resource prefix before that
        self.YEAR_PATTERN = re.compile(r"(.+/)y=\d{4}/$")
    def discover_resources(self, prefix: str = "") -> Iterable[str]:
        """Recursively walk prefixes to find resource roots (part before y=YYYY/)."""
        demisto.debug(f"[NSG] Discovering resources with prefix: {prefix}")
        for blob in self.client.walk_blobs(name_starts_with=prefix, delimiter="/"):
            if isinstance(blob, BlobPrefix):
                m = self.YEAR_PATTERN.match(blob.name)
                if m:
                    res_prefix = m.group(1)
                    demisto.debug(f"[NSG] Matched resource root: {res_prefix}")
                    yield res_prefix
                else:
                    # Keep walking deeper until we hit y=YYYY/
                    yield from self.discover_resources(prefix=blob.name)
    def list_blobs_for_hours(self, resource_prefix: str, hours_back: int = 0) -> Iterable[BlobProperties]:
        """
        List blobs under current UTC hour folder and up to 'hours_back' previous hours.
        """
        now = datetime.now(tz=timezone.utc)
        for h in range(hours_back + 1):
            ts = now - timedelta(hours=h)
            hour_marker = ts.strftime("y=%Y/m=%m/d=%d/h=%H/")
            blob_prefix = resource_prefix + hour_marker
            demisto.debug(f"[NSG] Listing blobs with prefix: {blob_prefix}")
            yield from self.client.list_blobs(name_starts_with=blob_prefix)
    def download_blob_json_tuned(self,
                                 blob: BlobProperties,
                                 max_concurrency: int = DEFAULT_MAX_CONCURRENCY,
                                 timeout: int = DEFAULT_DOWNLOAD_TIMEOUT,
                                 retries: int = DEFAULT_RETRY_ATTEMPTS,
                                 delay_base: int = DEFAULT_RETRY_DELAY_BASE) -> Tuple[str, Dict[str, Any]]:
        """
        Download blob and parse JSON with tuned transfer options & retries.
        Returns (blob_name, parsed_json or {}).
        """
        blob_client = self.client.get_blob_client(blob.name)
        demisto.debug(f"[NSG] Downloading blob: {blob.name} (max_concurrency={max_concurrency}, timeout={timeout})")
        for attempt in range(1, retries + 1):
            try:
                stream = blob_client.download_blob(max_concurrency=max_concurrency, timeout=timeout)
                data = stream.readall()  # bytes
                if not data or not data.strip():
                    demisto.debug(f"[NSG] Blob {blob.name} is empty.")
                    return blob.name, {}
                # json.loads accepts bytes; decoding is optional
                parsed = json.loads(data)
                return blob.name, parsed
            except json.JSONDecodeError as e:
                demisto.error(f"[NSG] JSON parse failed for {blob.name} ({attempt}/{retries}): {e}")
            except AzureError as e:
                demisto.error(f"[NSG] Azure error on {blob.name} ({attempt}/{retries}): {e}")
            except Exception as e:
                demisto.error(f"[NSG] Unexpected error on {blob.name} ({attempt}/{retries}): {e}")
            if attempt < retries:
                wait = delay_base * attempt
                demisto.debug(f"[NSG] Retrying {blob.name} in {wait}s...")
                time.sleep(wait)
        demisto.error(f"[NSG] Failed to download/parse blob {blob.name} after {retries} attempts.")
        return blob.name, {}
    def transform_record(self, record: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
        """Transform a single NSG record -> multiple flattened events (one per flow tuple)."""
        ts = record.get("time")
        mac = record.get("macAddress")
        resource_id = record.get("resourceId")
        operation_name = record.get("operationName")
        version = record.get("version")
        flows = record.get("properties", {}).get("flows", [])
        for flow in flows:
            rule = flow.get("rule")
            for group in flow.get("flows", []):
                for tuple_str in group.get("flowTuples", []):
                    fields = tuple_str.split(",")
                    # Defensive: ensure enough fields
                    if len(fields) < 13:
                        demisto.debug(f"[NSG] Skipping tuple (insufficient fields): {tuple_str}")
                        continue
                    event = {
                        "_raw_log": tuple_str,                # original tuple string
                        "ResourceId": resource_id,
                        "OperationName": operation_name,
                        "Version": version,
                        "Rule": rule,
                        "MacAddress": mac,
                        "Timestamp": ts,
                        "SourceIP": fields[1],
                        "DestinationIP": fields[2],
                        "SourcePort": fields[3],
                        "DestinationPort": fields[4],
                        "Protocol": fields[5],
                        "TrafficFlow": "Inbound" if fields[6] == "I" else "Outbound",
                        "TrafficDecision": "Allowed" if fields[7] != "D" else "Denied",
                        "FlowState": fields[8],
                        "PacketsSent": fields[9],
                        "BytesSent": fields[10],
                        "PacketsReceived": fields[11],
                        "BytesRecevied": fields[12],
                    }
                    yield event

# ----------------------
# Blob processing
# ----------------------
def process_blob(resource_prefix: str,
                 blob: BlobProperties,
                 last_index: Dict[str, int],
                 index_lock: threading.Lock,
                 parser: NSGFlowLogParser,
                 vendor: str,
                 product: str,
                 batch_size: int,
                 outbound_only: bool,
                 max_concurrency: int,
                 timeout: int):
    """
    Download + transform + send events for one blob.
    Uses last_index to avoid re-sending already processed records.
    """
    blob_name, log_json = parser.download_blob_json_tuned(
        blob=blob,
        max_concurrency=max_concurrency,
        timeout=timeout
    )
    records: List[Dict[str, Any]] = log_json.get("records", [])
    # Determine record slice to process
    last_processed = last_index.get(blob_name, -1)
    start_index = last_processed + 1
    new_records = records[start_index:]
    local_events: List[Dict[str, Any]] = []
    for record in new_records:
        for transformed in parser.transform_record(record):
            if outbound_only and transformed.get("TrafficFlow") != "Outbound":
                continue
            local_events.append(transformed)
    # Send in batches to XSIAM
    if local_events:
        sent_total = 0
        for batch in chunked(local_events, batch_size):
            send_events_to_xsiam(
                events=batch,
                vendor=vendor,
                product=product,
                should_update_health_module=True  # recommended for event collectors
            )
            sent_total += len(batch)
        demisto.info(f"[NSG] Sent {sent_total} events from blob {blob_name}")
    # Update index after successful send or if no events
    with index_lock:
        last_index[blob_name] = len(records) - 1 if records else last_processed

# ----------------------
# Build BlobServiceClient with transfer tuning
# ----------------------
def build_blob_service_client(params) -> BlobServiceClient:
    """
    Build BlobServiceClient using connection string auth, with transfer tuning.
    (DefaultAzureCredential path can be added if you use Entra ID/RBAC; connection string suits XSIAM collectors.)
    """
    conn_str = params.get("connection_string")
    if not conn_str:
        raise ValueError("Missing 'connection_string' parameter.")
    max_single_get_size = int(params.get("max_single_get_size_mb", DEFAULT_MAX_SINGLE_GET_SIZE_MB)) * 1024 * 1024
    max_chunk_get_size = int(params.get("max_chunk_get_size_mb", DEFAULT_MAX_CHUNK_GET_SIZE_MB)) * 1024 * 1024
    # Construct with tuned transfer kwargs (supported by SDK)
    # Ref: Microsoft Learn & SDK docs
    return BlobServiceClient.from_connection_string(
        conn_str=conn_str,
        max_single_get_size=max_single_get_size,
        max_chunk_get_size=max_chunk_get_size
    )

# ----------------------
# Main
# ----------------------
def main():
    params = demisto.params()
    command = demisto.command()
    demisto.info(f"Command being called is {command}")
    try:
        container_name = params.get("container_name")
        vendor = params.get("vendor", "Vendor")
        product = params.get("product", "AzureNSG")
        # Tunables & options
        batch_size = int(params.get("batch_size", DEFAULT_BATCH_SIZE))
        max_workers = int(params.get("max_workers", DEFAULT_MAX_WORKERS))
        hours_back = int(params.get("hours_back", 0))  # 0=current hour only
        outbound_only = bool(params.get("outbound_only", False))
        # Azure download tunables
        max_concurrency = int(params.get("max_concurrency", DEFAULT_MAX_CONCURRENCY))
        download_timeout = int(params.get("download_timeout", DEFAULT_DOWNLOAD_TIMEOUT))
        if command == "test-module":
            test_module()
            return
        elif command == "fetch-events":
            if not container_name:
                return_error("Please configure 'container_name' in the instance settings.")
            blob_service_client = build_blob_service_client(params)
            parser = NSGFlowLogParser(blob_service_client, container_name)
            # Load indexing state
            context = get_integration_context() or {}
            last_index = context.get("index", {})
            if not isinstance(last_index, dict):
                last_index = {}
            index_lock = threading.Lock()
            # Enumerate blobs to process (current hour ± hours_back)
            blobs_to_process: List[Tuple[str, BlobProperties]] = []
            for resource_prefix in parser.discover_resources():
                for blob in parser.list_blobs_for_hours(resource_prefix, hours_back=hours_back):
                    blobs_to_process.append((resource_prefix, blob))
            demisto.info(f"[NSG] Total blobs to process: {len(blobs_to_process)}")
            # Threaded processing of blobs
            max_workers = min(max_workers, len(blobs_to_process)) or 1
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [
                    executor.submit(
                        process_blob,
                        resource_prefix,
                        blob,
                        last_index,
                        index_lock,
                        parser,
                        vendor,
                        product,
                        batch_size,
                        outbound_only,
                        max_concurrency,
                        download_timeout
                    )
                    for (resource_prefix, blob) in blobs_to_process
                ]
                for f in as_completed(futures):
                    try:
                        f.result()
                    except Exception as e:
                        demisto.error(f"[NSG] Error processing blob in thread: {e}")
            # Persist indexing state
            set_integration_context({"index": last_index})
            # Return a minimal entry to avoid decoder (2605) errors.
            return_results(f"fetch-events completed. blobs={len(blobs_to_process)}")
        else:
            return_error(f"Unsupported command: {command}")
    except Exception:
        # Re-raise with full traceback for easier diagnosis
        raise Exception(f"Error in AzureNSG Integration: {traceback.format_exc()}")

if __name__ in ("__main__", "__builtin__", "builtins"):
    main()


